package codeGeneration;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class CodeGeneration {

    private String filename;
    private PrintStream ps;

    public CodeGeneration(String filename) throws FileNotFoundException {
        this.filename = filename;
        this.ps = new PrintStream(new FileOutputStream((this.filename)));
    }
}
